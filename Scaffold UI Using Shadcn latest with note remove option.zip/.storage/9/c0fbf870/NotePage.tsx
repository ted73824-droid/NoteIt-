import { useParams, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/Layout';
import { getNoteById, removeNoteById } from '@/data/departments';
import { Button } from '@/components/ui/button';
import { ChevronLeft, FileText, BookOpen, Calendar, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { FileViewer } from '@/components/FileViewer';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { toast } from '@/components/ui/use-toast';

export default function NotePage() {
  const { noteId } = useParams<{ noteId: string }>();
  const navigate = useNavigate();
  const noteData = getNoteById(noteId || '');
  const { isAdmin } = useAuth();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  useEffect(() => {
    // Scroll to top when note changes
    window.scrollTo(0, 0);
  }, [noteId]);

  if (!noteData) {
    return (
      <Layout>
        <div className="container py-16 text-center">
          <h1 className="text-4xl font-bold mb-4">Note Not Found</h1>
          <p className="mb-8">The note you're looking for doesn't exist.</p>
          <Button onClick={() => navigate('/')}>Return to Home</Button>
        </div>
      </Layout>
    );
  }

  const { note, subject, branch, department } = noteData;

  const renderNoteContent = () => {
    if (note.fileType === 'markdown') {
      return (
        <div className="prose prose-slate max-w-none">
          <ReactMarkdown>{note.content}</ReactMarkdown>
        </div>
      );
    } else {
      return (
        <FileViewer
          fileType={note.fileType}
          fileUrl={note.fileUrl}
          fileName={`${note.title}.${note.fileExtension || note.fileType}`}
          fileExtension={note.fileExtension}
        />
      );
    }
  };

  const handleDeleteNote = () => {
    if (noteId) {
      const success = removeNoteById(noteId);
      
      if (success) {
        toast({
          title: "Note Deleted",
          description: `"${note.title}" has been successfully removed.`,
          variant: "default",
        });
        // Navigate back to the subject page
        navigate(`/departments/${department.slug}/branches/${branch.slug}/subjects/${subject.slug}`);
      } else {
        toast({
          title: "Error",
          description: "Failed to delete the note. Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  return (
    <Layout>
      <div className="container py-8">
        <div className="flex justify-between items-start mb-6">
          <Button
            variant="ghost"
            className="flex items-center gap-2"
            onClick={() => navigate(`/departments/${department.slug}/branches/${branch.slug}/subjects/${subject.slug}`)}
          >
            <ChevronLeft className="h-4 w-4" /> Back to {subject.name}
          </Button>

          {/* Admin Delete Button */}
          {isAdmin() && (
            <Button
              variant="destructive"
              size="sm"
              onClick={() => setShowDeleteDialog(true)}
              className="flex items-center gap-2"
            >
              <Trash2 className="h-4 w-4" /> Remove Note
            </Button>
          )}
        </div>

        <div className="mb-6 space-y-4">
          <div className="flex items-center gap-2">
            {note.batch && (
              <Badge variant="outline" className="text-xs">
                <Calendar className="h-3 w-3 mr-1" />
                Batch: {note.batch}
              </Badge>
            )}
            {note.isHandwritten && (
              <Badge variant="outline" className="text-xs">
                Handwritten
              </Badge>
            )}
            <Badge variant="secondary" className="text-xs">
              <FileText className="h-3 w-3 mr-1" />
              {note.fileType.toUpperCase()}
              {note.fileExtension ? ` (${note.fileExtension})` : ''}
            </Badge>
          </div>

          <h1 className="text-3xl font-bold">{note.title}</h1>
          <p className="text-muted-foreground">{note.description}</p>
          <div className="text-sm text-muted-foreground flex items-center">
            <BookOpen className="h-4 w-4 mr-1" />
            <span className="mr-4">Subject: {subject.name}</span>
            <span>Last updated: {new Date(note.updatedAt).toLocaleDateString()}</span>
          </div>
        </div>

        {renderNoteContent()}

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure you want to delete this note?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This note will be permanently removed from the system.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDeleteNote} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </Layout>
  );
}